import ytmusicapi

def connexion():
    #print(
    #    "Vous allez être regirigé·e vers deezer pour vous connecter à votre compte.\n"
    #    "Puis appuyez sur Ctrl+Shift+i, cliquez sur Network(ou résaux), entrez /browse dans la barre de recherche.Si rien n'apparaît, cliquez sur bibliothèque.\n"
    #    "Sur firefox faites clic droit > copy (copier) > request headers(les entêtes de requetes). \n"
    #    """Sur un autre navigateur, cliquez sur le nom d'une requête, dans l'onglet "Headers"(En tête), alllez dans la section “Request headers”(En tête de requètes) et copiez tout de “accept: */*” à la fin de la section """)
    #a = input("Appuyer sur 'Entrer' pour continuer.")
    #webbrowser.open("https://www.music.youtube.com/")
    #headers = str(input("Collez ici :"))
    ytmusicapi.YTMusic.setup(filepath="headers_auth.json",headers_raw="""POST /youtubei/v1/browse?key=AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30 HTTP/1.1
Host: music.youtube.com
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0
Accept: */*
Accept-Language: fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3
Accept-Encoding: gzip, deflate, br
Content-Type: application/json
Content-Length: 2000
X-Goog-Visitor-Id: CgtGckFMQk9rU0pEMCinkrWMBg%3D%3D
X-Youtube-Client-Name: 67
X-Youtube-Client-Version: 1.20211108.00.00
X-Goog-AuthUser: 0
X-Origin: https://music.youtube.com
Origin: https://music.youtube.com
Sec-Fetch-Dest: empty
Sec-Fetch-Mode: same-origin
Sec-Fetch-Site: same-origin
Authorization: SAPISIDHASH 1636649263_4f33b3c8f72a82eb9e73686d7b154674144b7309
Referer: https://music.youtube.com/
Alt-Used: music.youtube.com
Connection: keep-alive
Cookie: CONSENT=YES+srp.gws-20211108-0-RC1.fr+FX+611; VISITOR_INFO1_LIVE=FrALBOkSJD0; _gcl_au=1.1.742680285.1636624386; PREF=volume=100&library_tab_browse_id=FEmusic_liked_playlists; SID=Dgg0ZmO5dgjXuzHxjPxa4DiZ-_1rSpcxCuHLpXyYiMRAnILqxrlend5uSyxVvRsBVZkndQ.; __Secure-1PSID=Dgg0ZmO5dgjXuzHxjPxa4DiZ-_1rSpcxCuHLpXyYiMRAnILq39sHWtJAU2Iq2V-c1_1HqQ.; __Secure-3PSID=Dgg0ZmO5dgjXuzHxjPxa4DiZ-_1rSpcxCuHLpXyYiMRAnILqzn0kh9Dge5O8P7S7aLSK4A.; HSID=AcnzwDizfE1ED61wY; SSID=AjObUPBEvpr7XI5Kk; APISID=Mn_NGgI_RnZ4LNXj/A_Maye45slSutxWZh; SAPISID=0l7KkaspmnDUOPB8/A7wiR0uDHdLjq2iIr; __Secure-1PAPISID=0l7KkaspmnDUOPB8/A7wiR0uDHdLjq2iIr; __Secure-3PAPISID=0l7KkaspmnDUOPB8/A7wiR0uDHdLjq2iIr; LOGIN_INFO=AFmmF2swRAIgPL1w8R4V9FvAHJEBmr-ybTe7tL3IvwmaP84-TtPyR7ACIFNPWbZah3yMc-yuJXBIhcKwLtRPbJqthURZgJ6pdiO0:QUQ3MjNmeHVoaTZMYVdHX3R2WGd2M3FPSHJnek9nMjA1U3ZsMGIyNUhzblJKcVlXNmY1ck9tZDBKak1fQU5wM1N1QnhIU0F6WlF2RlFKaXlJSlBDRzEyZGhiS2VMY0k5UXdXeXllQVN1N29tZlVaM0JVbnI2LW5kRUprZF9VSkV1ZG9hdGdGeEU4OTBzVXlXOVdkWDNONk1QZUh1aEdfbTNB; SIDCC=AJi4QfFCxTphaHfSNpxBK1SVPLmeC4jFct0_3wTm3-qS0tuRb7AvPYFh8R2T0XC_S1LMuz2hClE; __Secure-3PSIDCC=AJi4QfEQ35o-NJ_NEPvjAiXEPR_Lcb1IG74WXqd-NbIXDN6KYYR94um_3B9nR5OSMI56pNh8YA; YSC=IGoxfvFtChw""")
    ytm = ytmusicapi.YTMusic("headers_auth.json")
    return ytm

def recuperation_playliste_ytm(yt):
    liste_playlist = yt.get_library_playlists()
    for i in range(len(liste_playlist)):
        print(f"{i + 1} : {liste_playlist[i]['title']}")
    playlists_selectionner = False
    while playlists_selectionner == False:
        choix = input("Veuillez choisir la playlist à selectioner : ")

        try:
            choix = int(choix)

            liste_playlist[choix - 1]
            assert choix > 0

            playlists_selectionner = True

        except :
            print("ERREUR : Veuillez saisir un ID valide\n")

    print(f"Vous avez selectionné la playlist : {liste_playlist[(choix - 1)]['title']}\n")
    id_de_playlist=liste_playlist[choix-1]["playlistId"]
    
    playlist=yt.get_playlist(id_de_playlist)
    
    liste_sons = []
    
    n=-1
    for i in playlist["tracks"]:
        n+=1
        son = [playlist["tracks"][n]["title"],playlist["tracks"][n]["album"]["name"],playlist["tracks"][n]["artists"][0]["name"] ]
        liste_sons.append(son)

        
    return liste_sons


def creation_playlist(yt,playlist):
    nom = input("Nom de la playlist : ")
    print("veuillez patienter quelques secondes")
    idplaylist=yt.create_playlist(nom,"Playlist importée")
    playlistId=[]
    for i in playlist :
        recherche = str(i[0]+" "+i[2])
        liste_resultats = yt.search(query=recherche,filter="songs")
        playlistId.append(liste_resultats[0]["videoId"])
    abc = yt.add_playlist_items(idplaylist,playlistId)
    return "Playlist créée avec succès"