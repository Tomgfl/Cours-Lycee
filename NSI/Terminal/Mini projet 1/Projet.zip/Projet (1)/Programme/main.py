# Importation des modules et fonctions
import fct_deezer
import fct_spotify
import fct_ytm


### Main ###


def Spotify_to_deezer():
    """ Convertiseur de Spotify a Deezer """

    # Connexion aux comptes
    sp = fct_spotify.connexion_spotify()
    dz, client = fct_deezer.connexion_deezer()
    
    # Recuperation de la playlist sur Spotify
    a_convertir = fct_spotify.recuperation_playliste_spotify(sp)
    
    # Creation et convertion sur deezer
    fct_deezer.creation_playlist(dz,client,a_convertir)
    
    
def Deezer_to_spotify():
    """ Convertiseur de Deezer a Spotify """

    # Connexion aux comptes
    dz, client = fct_deezer.connexion_deezer()
    sp = fct_spotify.connexion_spotify()
    
    # Recuperation de la playlist sur Deezer
    a_convertir = fct_deezer.recuperation_playlist_deezer(dz,client)

    # Creation et convertion sur spotify
    fct_spotify.creation_playlist(sp,a_convertir)


def Spotify_to_ytmusic():
    """ Convertiseur de Spotify a YouTube Music """

    # Connexion aux comptes
    sp = fct_spotify.connexion_spotify()
    yt = fct_ytm.connexion()
    
    # Recuperation de la playlist sur Spotify
    a_convertir = fct_spotify.recuperation_playliste_spotify(sp)
    
    # Creation et convertion sur deezer
    fct_ytm.creation_playlist(yt,a_convertir)


def ytmusic_to_deezer():
    """ Convertiseur de YouTube Music a Deezer """

    # Connexion aux comptes
    yt = fct_ytm.connexion()
    dz, client = fct_deezer.connexion_deezer()
    
    # Recuperation de la playlist sur Spotify
    a_convertir = fct_ytm.recuperation_playliste_ytm(yt)
    
    # Creation et convertion sur deezer
    fct_deezer.creation_playlist(dz,client,a_convertir)


def ytmusic_to_spotify():
    """ Convertiseur de YouTube Music a Spotify """

    # Connexion aux comptes
    yt = fct_ytm.connexion()
    sp = fct_spotify.connexion_spotify()
    
    # Recuperation de la playlist sur Deezer
    a_convertir = fct_ytm.recuperation_playlist_ytm(yt)

    # Creation et convertion sur spotify
    fct_spotify.creation_playlist(sp,a_convertir)


def Deezer_to_ytmusic():
    """ Convertiseur de Deezer a YouTube Music """

    # Connexion aux comptes
    dz, client = fct_deezer.connexion_deezer()
    yt = fct_ytm.connexion()
    
    # Recuperation de la playlist sur Deezer
    a_convertir = fct_deezer.recuperation_playlist_deezer(dz,client)

    # Creation et convertion sur spotify
    fct_ytm.creation_playlist(yt,a_convertir)


