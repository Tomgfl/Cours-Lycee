# coding: utf-8
# nom : factorielle_n_prog_fct_recursif.py
# rôle : Calcul de la factorielle d'un entier naturel n
# Appel de la fonction récursive factorielle_recursif(N)

# déclaration de la fonction factorielle(N)
def factorielle_recursif(N):
    # Rappel 0! = 1
    # si n = 0
    if N == 0:
        return 1
    else:
        return N*factorielle_recursif(N-1)
    
# Début algorithme

# Soit  un entier naturel
# Initialisation des variables et constantes
#       n = 0
n = 0

# Présentation du programme
print("Calcul de Factorielle(n)")

# Saut de ligne
print ()

# Lire n
n = int(input("Veuillez saisir l'entier n : "))

# Saut de ligne
print ()

# Ecrire le résultat
print(f"factorielle({n}) = {factorielle_recursif(n)}")



