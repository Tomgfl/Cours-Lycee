# nom : pgcd_ppcm_facto_module.py
# rôle : Module de fonctions regroupant:
# la fonction pgcd
# la fonction ppcm
# la fonction factorielle

# Début Module

# déclaration de la fonction pgcd
def pgcd(x,y):
    # Tant que y non nul
    while y != 0:
        # Calculer r le reste de la division de x par y
        r = x % y
        # x <-- y
        x = y
        # y <-- r
        y = r
    # Valeur de retour <-- PGCD
    return x



# déclaration de la fonction ppcm
def ppcm(x,y):
    # c <-- x et d <-- y
    c,d=x,y

    # TANT_QUE x != y FAIRE
    while x!=y:
        # SI a>b ALORS
        if x > y:
            # y <-- y+d
            y+=d      
        # AUTREMENT SI x<y ALORS
        elif x < y:
            # x <-- x+c
            x+=c

    # x valeur de retour est le PPCM
    return x

# déclaration de la fonction factorielle(N)
def factorielle(N):
    # Rappel 0! = 1
    # Initialisation des variables et constantes
    #       i = 0
    #       resultat = 1
    (i,resultat,) = (0,1,)
    
    # Si N non nul alors
    if N :
        # Boucle de calcul de factorielle(N)
        # Pour i allant de 1 à N Faire
        for i in range(1, N+1):
            # Factorielle = 1*....*N-1*N
            resultat *= i

    # x valeur de retour est le PPCM
    return resultat


# Fin module

