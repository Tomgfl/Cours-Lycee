# coding: utf-8
# nom : pgcd_prog_recursif_2.py
# rôle : Calcul du PGCD de deux nombres a et b à l'aide
# de l'algorithme d'Euclide
# Appel de la fonction récursive pgcd_recursif()

def pgcd_recursif(x,y):
    # Initialisation des variables et constantes
    temp = 0
    # Si y nul
    if y == 0:
        # Valeur de retour x <-- PGCD
        return x
    else:
        #savegarde de x : temp <-- x
        temp = x
        # x <-- y
        x = y
        # y <-- reste de la division euclidienne de x par y
        y = temp % y
        # Calcul de pgcd(x,y)
        # Valeur de retour <-- pgcd(x,y)
        return pgcd_recursif(x,y)

# Début algorithme
# Soient a et b deux entiers naturels
# Initialisation des variables et constantes
#       a = 0
#       b = 0
(a,b,) = (0,0,)


# Présentation du programme
print("Calcul du PGCD(a,b)")

# Saut de ligne
print ()

# Lire a
a = int(input("Veuillez saisir l'entier a : "))

# Lire b
b = int(input("Veuillez saisir l'entier b : "))
        
      
# Ecrire le PGCD
print(f"LE PGCD({a},{b}) est : {pgcd_recursif(a,b)}")
