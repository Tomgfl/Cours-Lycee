# coding: utf-8
# nom : recherche_dichotomique_fct_recursive.py
# rôle : recherche récursive d'une chaine de caractères dans un fichier
# à l'aide de la Méthode dichotomique
# Appel de la fonction récursive recherche_mot()


# Déclaration de la fonction recherche_dico()
def recherche_dico(mot, uneListe):
    # Initialisation des variables et constantes
    # indiceDebut <-- 0
    indiceDebut = 0
    # indiceFin <-- indice de fin de liste
    indiceFin = len(uneListe) - 1
    # Valeur de retour <-- recherche_mot(mot, uneListe, indiceDebut, indiceFin)
    return recherche_mot(mot, uneListe, indiceDebut, indiceFin)

# Déclaration de la fonction récursive recherche_mot()
def recherche_mot(motRecherche, dansUneListe, debut, fin):
    # Initialisation des variables et constantes
    # Indice du milieu d'intervalle <-- (début + fin)//2    
    indiceIntervalle = (debut + fin) // 2
    # Si le mot situé au milieu de l'intervalle de recherche est le mot recherché
    if motRecherche.strip() == dansUneListe[indiceIntervalle].strip():
        # Valeur de retour <-- indice de l'intervalle
        return indiceIntervalle
    # Si la borne de début et la borne de fin de l'intervalle de fin coïncident
    if debut == fin:
        # Valeur de retour <-- 0
        return 0
    # Si mot recherché est situé dans moitié inférieure de l'intervalle de recherche
    if motRecherche.strip() < dansUneListe[indiceIntervalle].strip():
        # Valeur de retour <-- recherche_mot dans la moitié inférieure de l'intervalle de recherche
        # Nouvel intervalle de recherche = moitié inférieure du précédent intervalle de recherche
        return recherche_mot(motRecherche, dansUneListe, debut, indiceIntervalle-1)
    else: 
        # Valeur de retour <-- recherche_mot dans la moitié supérieure de l'intervalle de recherche
        # Nouvel intervalle de recherche = moitié supérieure du précédent intervalle de recherche
        return recherche_mot(motRecherche, dansUneListe, indiceIntervalle+1, fin)

# Début algorithme

# Saut de ligne
print ()

# Présentation du programme
print("Recherche d'un mot dans un dictionnaire")

# Saut de ligne
print ()

# Lire le mot recherché
print("Saisir le mot que vous recherchez :",end="")
motDico = input()

# Saut de ligne
print ()

#ouverture du fichier dictionnaire en mode lecture
monFichier = open("./liste_francais.txt",'r')

#Charger le ficher dans une liste de chaine
maListe = monFichier.readlines()

# Fermeture du fichier
monFichier.close()

# Initialisation des variables et constantes
position_mot = recherche_dico(motDico, maListe)

# Si le mot n'a pas été trouvé
if not position_mot :
    # Informer l'utilisateur du résultat de la recherche
    print("le mot recherché n'a pas été trouvé")
# Autrement
else:
    # Donner la position du mot dans le dictionnaire
    print(f"Le mot recherche est situé en {position_mot + 1} ième position dans le dictionnaire")

# Fin de l'algorithme
    
