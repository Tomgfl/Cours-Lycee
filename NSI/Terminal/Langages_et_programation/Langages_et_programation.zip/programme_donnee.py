#presentation du programme
print('Importation des programmes : \n- PGCD de deux entiers naturels a et b\n- PGCM de deux entiers naturels a et b\n- Factorielle d’un entier naturel n\n')

#appel des programmes
import PGCD
import ppcm_rapport
import factorielle_n

#from PGCD import*
#from ppcm_rapport.py import*
#from factorielle_n.py import*
