class Chaine:
    chaine_1 = "python est un langage vraiment sympa"
