from classe_personne import *



perso_1 = Personne()
perso_2 = Personne()

print("Saisie des caracteristique de la premiere Personne")
perso_1.saisie_carac()
print()

print("Saisie des caracteristique de la deuxieme Personne")
perso_2.saisie_carac()
print()

print("Affichage des caracteristique de la premiere Personne")
perso_1.affich_carac()
print()

print("Affichage des caracteristique de la deuxieme Personne")
perso_1.affich_carac()
