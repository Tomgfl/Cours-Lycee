def image(fct):
    for i in range(10,21):
        print("a ",i," on associe ",fct(i))

cube = lambda x:x**3
