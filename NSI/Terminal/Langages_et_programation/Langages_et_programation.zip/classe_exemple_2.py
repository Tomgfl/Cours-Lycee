class MaPhrase:
    def __init__(self,ma_phrase):
        self.mots = ma_phrase.split()

