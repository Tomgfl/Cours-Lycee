# coding: utf-8
# nom du programme : deuxPuissance_algo.py
# rôle : calculer et afficher les puissances de l'entier 2

# Initilisation des variables et constantes
# exposant <-- 0
# ... code ...

# résultat <-- 1
# ... code ...



# Entrée clavier de l'exposant
# ... code ...


# Pour i allant de 0 à l'exposant exclu
# ... code ...


    # résultat <-- resultat * 2
    # ... code ...


# Afficher le résultat (sortie écran)
# ... code ...




