# coding: utf-8
# nom du programme : deuxPuissance_signée_algo
# rôle : calculer et afficher les puissances de l'entier 2
# propriété : l'exposant est un entier relatif

# Initilisation des variables et constantes
# exposant <-- 0
# ... code ...

# résultat <-- 1
# ... code ...


# Entrée clavier de l'exposant
# ... code ...


# Traitement du signe de l'exposant
# Si l'exposant est négatif
# ... code ...

    # Pour i allant de 0 à la valeur absolue de l'exposant exclu
    
    # ... code ...
    
        # resultat <-- resultat / 2
        # ... code ...

# Sinon
# ... code ...
    # Pour i allant de 0 à l'exposant exclu
    # ... code ...

        # resultat <-- resultat *2
        # ... code ...

# Afficher le résultat (sortie écran)
# ... code ...







