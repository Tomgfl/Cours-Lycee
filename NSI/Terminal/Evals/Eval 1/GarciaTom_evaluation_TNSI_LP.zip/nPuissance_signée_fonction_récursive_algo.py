# coding: utf-8
# nom du programme : nPuissance_signée_fonction_récursive_algo
# rôle : calculer et afficher les puissances de l'entier n
# propriété : appelle la récursive fonction nPuissance
#           : l'entier et l'exposant sont des entiers relatifs
#           : le programme vérifie le type des entrées clavier et
#           : rejette toute entrée clavier non conforme 


# declaration de la fonction
#... code...

    # verification try
    #... code...
        # verification que x est un entier relatif
        #... code...
        # verification que y est un entier relatif
        #... code...
    # except une erreur
    #... code...

        #affichage du message d'erreur
        #... code...
    

    # si l'exposant est nul
    #... code...
        # retourner 1
        #... code...
    # sinon si l'exposant est negatif
    #... code...
        #retourner 1 / par x la fonction de parametre x et la valeur absolue de y
        #... code...
    # sinon 
    #... code...
        # retourner x*la fonction recursive de parametre x et y-1 
        #... code...


# debut du programme

# affichage de l'énoncer du programe
#...code...

# verification des valeurs
#...code...
    # verification de l'entier x
    #...code...
    # verification de l'exposant entier y 
    #...code...
# except erreur
#...code...
    # message erreur
    #...code...

# affichage resultat
#...code...







    
