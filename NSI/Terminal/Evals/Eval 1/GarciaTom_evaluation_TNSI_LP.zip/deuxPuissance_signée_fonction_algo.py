# coding: utf-8
# nom du programme : deuxPuissance_signée_algo
# rôle : calculer et afficher les puissances de l'entier 2
# propriété : l'exposant est un entier relatif


# declaration de la fonction
# ... code ...

    # declaration de la fonction
    # ... code ...

    # si x(exposant) est negatif
    # ... code ...

        # pour i allant de 0 à la valeur absolue de l'exposant exclu
        # ... code ...

            # resultat = resultat / 2
            # ... code ...
    # sinon
    # ... code ...

        # pour i allant de 0 à l'exposant exclu
        # ... code ...

            # resultat = resultat * 2
            # ... code ...
    # retourner le resultat
    # ... code ...


