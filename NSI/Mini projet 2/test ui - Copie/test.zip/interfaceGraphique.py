from tkinter import *
from tkinter.ttk import *
import PIL.Image as Image
import PIL.ImageTk as ImageTk
from urllib.request import urlopen
from io import BytesIO
import webbrowser
from functools import partial


from main import *


# Initialisation de la fenetre
master = Tk()

#Creation de la zone pour tous les articles
Frame_allArticles = Frame(master)
Frame_allArticles.grid(row=1,column=0,sticky=W)


Frame_filtres = Frame(master)
Frame_filtres.grid(row=0,column=0,sticky=W)
                   
# Création de la zone de texte 1
label1= Label(Frame_filtres, text="Entrez votre recherche :")
# Ancrage de la zone de texte 1
label1.grid(row=0, column=0,padx=5,pady=5)

# Création de la barre de recherche
recherche = Entry(Frame_filtres)
# Ancrage de la barre de recherche
recherche.grid(row = 1, column = 0, sticky = W, pady = 2,padx=5) 


def print_item(article,ID):
    global Frame_allArticles

    #placement
    ID_x = ID%10
    ID_y = ID//10

    #frame
    Frame_article = Frame(Frame_allArticles)

    #image
    photo = open_from_url(article.url_img)
    Label_image = Label(Frame_article, image=photo)
    Label_image.photo = photo
    Label_image.grid(row=0, column=0)

    #nom
    if len(article.nom) > 17:
        nom = article.nom[0:15]+'...'
    else:
        nom = article.nom
    Label_text_nom = Label(Frame_article, text=nom)
    Label_text_nom.grid(row=1, column=0, sticky = W)

    #prix
    Label_text_prix = Label(Frame_article, text=str(article.prix)+' €')
    Label_text_prix.grid(row=2, column=0, sticky = W)

    #bouton lien
    Label_button = Button(Frame_article,text="Ouvrir",command=partial(open_browser,article.url))
    Label_button.grid(row=3,column=0,sticky = W)

    Frame_article.grid(row=3+ID_y, column=ID_x, sticky = W)

    
def open_browser(url):
    webbrowser.open(url)

def open_from_url(url):
    print(url)
    u = urlopen(url)
    raw_data = u.read()
    u.close()
    im = Image.open(BytesIO(raw_data))
    im_resize = im.resize((100,120))
    photo = ImageTk.PhotoImage(im_resize)
        
    return photo

# Définition de la fonction recupere() qui récupère les valeurs de toutes les entrées et les attribue aux variables liées
def recupere():
    motrecherche=recherche.get()
    prixmin = int(pmin.get())
    prixmax= int(pmax.get())
    nombrearticle= int(nbart.get())
    sites = []
    if shpock.get():
        sites.append("shpock")
    if ebay.get() :
        sites.append("ebay")
    if vint.get():
        sites.append("vinted")
        
    allArticles = main(motrecherche,nombrearticle,prixmin,prixmax,sites)

    
    for i in range(len(allArticles)):
        print_item(allArticles[i],i)


    

# Création du bouton valider qui déclenche la fonction recupere
bouton = Button(Frame_filtres, text="Valider", command=recupere)
# Ancrage du bouton
bouton.grid(row = 2,column = 0, sticky = W, pady= 2, padx=27)

# Création de la zone de texte 2
label2 = Label(Frame_filtres, text= "Prix minimum :")
# Ancrage de la zone de texte 2
label2.grid(row = 0, column = 1,sticky = E, pady=5)

# Création de l'entrée du prix minimal
pmin = Spinbox(Frame_filtres,width=7,from_=0,to=10000)
# Ancrage de celle ci
pmin.grid(row = 0, column= 2, pady= 5)

# Création de la zone de texte 3
label3 = Label(Frame_filtres, text= "Prix maximum :")
# Ancrage de la zone de texte 3
label3.grid(row = 1, column = 1,sticky = E, pady=5)

# Création de l'entrée du prix minimal
pmax = Spinbox(Frame_filtres,width=7,from_=0,to=10000)
# Ancrage de celle-ci
pmax.grid(row = 1, column= 2, pady= 5)

# Création de la zone de texte 4
label4 = Label(Frame_filtres, text= "Nombre d'articles par site :")
# Ancrage de la zone de texte 4
label4.grid(row = 2, column = 1, pady=5)

# Création de l'entrée du nombre d'articles par site
nbart = Spinbox(Frame_filtres,width=7,from_=1,to=10000)
# Ancrage de celle-ci
nbart.grid(row = 2, column= 2, pady= 5)

# Initialisation de la variable entière vint
vint= IntVar()
# Création de la case à cocher qui correspond à la variable vint
vt = Checkbutton(Frame_filtres, text="Vinted",variable = vint)
# Ancrage de celle-ci
vt.grid(row = 0, column = 3, pady = 5,padx = 10, sticky = W)

# Initialisation de la variable entière face
shpock = IntVar()
# Création de la case à cocher qui correspond à la variable face
sh = Checkbutton(Frame_filtres, text="Shpock",variable = shpock)
# Ancrage de celle-ci
sh.grid(row = 1, column = 3,padx = 10, pady = 5, sticky = W)

# Initialisation de la variable entière topa
ebay = IntVar()
# Création de la case à cocher qui correspond à la variable topa
eb = Checkbutton(Frame_filtres, text="Ebay",variable = ebay)
# Ancrage de celle-ci
eb.grid(row = 2, column = 3, pady = 5,padx = 10, sticky = W)

master.mainloop()



























    
    
    
    




