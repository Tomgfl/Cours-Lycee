# Nom du fichier : classeArticle_algo.py
# Création de la classe Article contenant les attribut prix, site, url et url de l'image pour chaque instance.

    # définition de la méthode __init__(self,Prix,Nom,Site,Url,Url_img)
        
        # self.prix <-- Prix

        #self.nom <-- Nom
        
        # self.site <-- Site
        
        # self.url <-- Url
        
        # self.url_img <-- Url_img
